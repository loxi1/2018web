use Traductor2018;
go

alter table Persona add dni varchar(10) null;
select * from Persona;
select * from cliente;

select * from Usuario;